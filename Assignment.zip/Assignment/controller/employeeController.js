const express = require('express');

const mongoose = require('mongoose');

const Employee = mongoose.model('Employee');

const router = express.Router();

router.get("/",(req,res) => {
    res.render("employee/addOrEdit",{
        viewTitle:"Insert Movie"
    })
})

router.post("/",(req,res) => {
    if(req.body._id == "")
    {
    insertRecord(req,res);
    }
    else{
        updateRecord(req,res);
    }
})

function insertRecord(req,res)
{
   var employee = new Employee();

   employee.fullName = req.body.fullName;

   employee.imgurl = req.body.imgurl;

   employee.summary = req.body.summary;

   employee.save((err,doc) => {
       if(!err){
        res.redirect('employee/list');
       }
       else{
           
          if(err.name == "ValidationError"){
              handleValidationError(err,req.body);
              res.render("employee/addOrEdit",{
                  viewTitle:"Insert Movie Name",
                  employee:req.body
              })
          }

          console.log("Error occured during record insertion" + err);
       }
   })
}



router.get('/list',(req,res) => {

    Employee.find((err,docs) => {
        if(!err) {
            res.render("employee/list",{
               list:docs
            })
        }
    })
})





function handleValidationError(err,body){
    for(field in err.errors)
    {
        switch(err.errors[field].path){
        case 'fullName':
              body['fullNameError'] = err.errors[field].message;
              break;
        
       
        default:
           break;
        }
    }
}

module.exports = router;